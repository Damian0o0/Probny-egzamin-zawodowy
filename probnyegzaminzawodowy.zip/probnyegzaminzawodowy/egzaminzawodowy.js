var szerokosc = document.getElementById("szerokosc");
var wysokosc = document.getElementById("wysokosc");
var paragraf = document.getElementById("paragraf");
function oblicz() 
{
    var suma=2*2.7*wysokosc.value+2*2.7*szerokosc.value;
    var koszt = suma*8;
    paragraf.innerHTML = "powierzchnia całkowita ścian: "+suma+"<br>"+"Koszt malowania: "+koszt+"zł";
    console.log(suma);
}